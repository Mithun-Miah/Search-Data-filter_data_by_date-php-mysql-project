<?php

// Database Connection with mysql database
$connect = mysqli_connect("localhost", "root", "", "filter_data");

if($connect){
    // echo "Done";
}else{
    echo "Fail";
}

?>