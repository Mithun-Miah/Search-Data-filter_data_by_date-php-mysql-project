<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css">
    <title>Document</title>

</head>

<body>

    <div class="container">
        <div class="card mt-5">
            <div class="card-header text-center">
                <div class="h2">
                    Data Filter by Date Using PHP Mysql
                </div>
            </div>
            <div class="card-body">
                <form action="" method="GET">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>From Date</label>
                                <input type="date" name="from_date" class="form-control p-3">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>To Date</label>
                                <input type="date" name="to_date" class="form-control p-3">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Click to Filter</label>
                                <br>
                                <button type="submit" class="btn btn-primary p-3">Filter</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="card mt-4">
            <div class="card-body">
                <table class="table table-bordered text-center">
                    <thead>
                        <tr>
                            <th>#SL.</th>
                            <th>Category</th>
                            <th>Sub-Category</th>
                        </tr>
                    </thead>
                    <tbody>


                        <?php
                    include_once("config.php");

                    if(isset($_GET['from_date']) && isset($_GET['from_date'])){
                        $from_date = $_GET['from_date'];
                        $to_date = $_GET['to_date'];

                        $query = "SELECT * FROM records WHERE date BETWEEN '$from_date' AND '$to_date'";

                        $run_query = mysqli_query($connect, $query);

                        if(mysqli_num_rows($run_query) > 0){ 

                            foreach($run_query as $row){ ?>

                        <tr>
                            <td><?php $row['id']; ?></td>
                            <td><?php $row['category']; ?></td>
                            <td><?php $row['sub_category']; ?></td>
                        </tr>

                        <?php
                            }

                        }else{
                            echo "No Record Found";
                        }
                    }
                ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>